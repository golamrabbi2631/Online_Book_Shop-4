<?php
require('config.php');
$conn=mysqli_connect('localhost', 'root', '', 'shop_db');
$seql="SELECT * FROM products LIMIT 0,10";
require_once('fpdf/fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$width_cell=array(20,40,58,40);
$pdf->SetFont('Arial','B','16');
$pdf->SetFillColor(193,229,252);
$pdf->Cell($width_cell[0],10,'Id',1,0,'C',true);
$pdf->Cell($width_cell[1],10,'Name',1,0,'C',true);
$pdf->Cell($width_cell[2],10,'Price',1,0,'C',true);
$pdf->Cell($width_cell[3],10,'Image',1,1,'C',true);
$pdf->SetFont('Arial','',14);
$pdf->SetFillColor(235,236,236);
$fill=false;

foreach( $conn-> query( $seql) as $row) {
    $pdf->Cell($width_cell[0],10,$row['id'],1,0,'C',$fill);
    $pdf->Cell($width_cell[1],10,$row['name'],1,0,'C',$fill);
    $pdf->Cell($width_cell[2],10,$row['price'],1,0,'C',$fill);
    $pdf->Cell($width_cell[3],10,$row['image'],1,1,'C',$fill);
    $fill=!$fill;
}

$pdf->Output();
?>